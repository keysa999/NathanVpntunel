#!/bin/bash

limit=2

users=$(who | awk '{print $1}' | sort | uniq)

for user in $users
do
count=$(who | grep $user | wc -l)
if [ $count -gt $limit ]; then
pkill -u $user
fi
done
