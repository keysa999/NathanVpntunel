#!/bin/bash

config="/etc/xray/config.json"

sed -i 's/"email": "\(.*\)"/"email": "\1",\n"limitIp": 2/g' $config

systemctl restart xray
