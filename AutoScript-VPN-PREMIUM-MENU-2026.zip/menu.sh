#!/bin/bash

RED='\033[1;91m'
GREEN='\033[1;92m'
YELLOW='\033[1;93m'
BLUE='\033[1;94m'
MAGENTA='\033[1;95m'
CYAN='\033[1;96m'
WHITE='\033[1;97m'
RESET='\033[0m'

clear

width=$(tput cols)

center() {
    printf "%*s\n" $(((${#1}+$width)/2)) "$1"
}

line() {
    printf "%${width}s\n" | tr ' ' '═'
}

echo -e "${CYAN}"
line
center "🔥 AUTO SCRIPT VPN 2026 🔥"
center "Premium Neon Edition"
line
echo -e "${RESET}"

echo ""
echo -e "${GREEN}"
center "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
center "🚀 MAIN MENU 🚀"
center "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${RESET}"
echo ""

echo -e "${MAGENTA}"
center "[ 1 ] SSH MENU"
center "[ 2 ] XRAY MENU"
center "[ 3 ] WIREGUARD MENU"
center "[ 4 ] AUTO DOMAIN + SSL"
center "[ 5 ] ANTI MULTI LOGIN"
center "[ 6 ] SYSTEM MENU"
center "[ 7 ] RESTART ALL SERVICE"
center "[ 0 ] EXIT"
echo -e "${RESET}"
echo ""

echo -ne "${YELLOW}"
center "Select menu : "
echo -ne "${RESET}"
read opt

case $opt in
1)
bash ssh/menu.sh
;;
2)
bash xray/menu.sh
;;
3)
bash wireguard/menu.sh
;;
4)
bash system/autodomain.sh
;;
5)
bash system/limitssh.sh
;;
6)
bash system/menu.sh
;;
7)
systemctl restart ssh
systemctl restart xray
systemctl restart wg-quick@wg0
echo -e "${GREEN}"
center "All services restarted!"
echo -e "${RESET}"
sleep 2
bash menu.sh
;;
0)
exit
;;
*)
echo -e "${RED}"
center "Invalid option!"
echo -e "${RESET}"
sleep 1
bash menu.sh
;;
esac
