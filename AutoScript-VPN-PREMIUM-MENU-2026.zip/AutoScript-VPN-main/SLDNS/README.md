# SLDNS
SSH OVER DNS create by SL
* Link Script Repo SlowDNS dari Sulaiman L
```html
https://github.com/fisabiliyusri/SLDNS
```

Script Auto Installer SlowDNS
```html
wget -q -O /usr/bin/install-sldns "https://raw.githubusercontent.com/MujurID/AutoScript-VPN/main/SLDNS/install-sldns"
chmod +x /usr/bin/install-sldns
&&
install-sldns
```

# INFO
* INI SCRIPT BERSIFAT GRATIS DAN INI SCRIPT DI LARANG DI JUAL PERBELIKAN
* Ini Script bisa di Mod/Modifikasi/edit dengan bebas

# INFO Khusus SlowDNS
• SSH Over DNS (SlowDNS)
* untuk kecepatan nya di batasi
* speed download 3 Mbps (Max Speed)
* speed upload 100+ Mbps (Max Speed)
* Support semua port ssh

# SSH Only (Support All SSH Ports)
* Service Port DNS

# SERVER PORT:
* UDP SERVER 53,5300

# CLIENT PORT:
* UDP DNS 3369,2269
* DoT 169 [OFFLINE]
* DoH 99 [OFFLINE]
* SSH ALL PORT

# Support DNS Protokol
* UDP DNS
* DNS-over-TLS (DoT) (OFFLINE)
* DNS-over-HTTPS (DoH) (OFFLINE)
#
* SCRIPT SLOWDNS
* script slowdns
* Script Slowdns
* Script SlowDNS
* Script SSH Over DNS
