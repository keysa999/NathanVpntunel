#!/bin/bash

if [ ! -d "/root/.acme.sh" ]; then
curl https://get.acme.sh | sh
fi

read -p "Masukkan domain: " domain

systemctl stop nginx 2>/dev/null
systemctl stop xray 2>/dev/null

~/.acme.sh/acme.sh --issue -d $domain --standalone -k ec-256

mkdir -p /etc/xray

~/.acme.sh/acme.sh --install-cert -d $domain --ecc --key-file /etc/xray/xray.key --fullchain-file /etc/xray/xray.crt

echo $domain > /etc/xray/domain

systemctl start nginx 2>/dev/null
systemctl restart xray

echo "Auto Domain + SSL berhasil!"
